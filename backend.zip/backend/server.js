// const express = require('express');
// const bodyParser = require('body-parser');
// const cors = require('cors');
// const path = require('path'); 

// const app = express();
// const port = process.env.PORT || 3001;

// app.use(bodyParser.json());
// app.use(cors());

// // GET Route (Hardcoded)
// app.get('/bfhl', (req, res) => {
//   res.json({ operation_code: 1 });
// });

// // POST Route (Processing JSON Data)
// app.post('/bfhl', (req, res) => {
//   const data = req.body.data;

//   let numbers = [];
//   let alphabets = [];
//   let highestLowercaseAlphabet = '';

//   for (let i = 0; i < data.length; i++) {
//     if (!isNaN(parseInt(data[i]))) {
//       numbers.push(data[i]);
//     } else {
//       alphabets.push(data[i]);
//       if (highestLowercaseAlphabet < data[i].toLowerCase()) {
//         highestLowercaseAlphabet = data[i].toLowerCase();
//       }
//     }
//   }

//   res.json({
//     is_success: true,
//     user_id: 'john_doe_17091999', // Placeholder - Replace with your logic
//     email: 'john@xyz.com', // Placeholder - Replace with your logic
//     roll_number: 'ABCD123', // Placeholder - Replace with your logic
//     numbers,
//     alphabets,
//     highest_lowercase_alphabet: [highestLowercaseAlphabet],
//   });
// });

// // Serve static files from the React build directory
// app.use(express.static(path.join(__dirname, '../frontend/build')));

// // Serve index.html for all other requests
// app.get('/*', (req, res) => {
//   res.sendFile(path.join(__dirname, '../frontend/build/index.html')); 
// }); 

// app.listen(3001, () => {
//   console.log(`Server listening on port ${3001}`);
// });
// const express = require('express');
// const cors = require('cors');
// const bodyParser = require('body-parser');

// const app = express();
// const PORT = process.env.PORT || 3000;

// app.use(cors());
// app.use(bodyParser.json());

// // Your user details
// const USER_ID = 'john_doe_17091999';
// const EMAIL = 'john@xyz.com';
// const ROLL_NUMBER = 'ABCD123';

// app.post('/bfhl', (req, res) => {
//   try {
//     const { data } = req.body;

//     if (!Array.isArray(data)) {
//       return res.status(400).json({ is_success: false, message: 'Invalid input: data must be an array' });
//     }

//     const numbers = data.filter(item => !isNaN(item));
//     const alphabets = data.filter(item => isNaN(item));
//     const lowercaseAlphabets = alphabets.filter(item => item.toLowerCase() === item);
//     const highestLowercaseAlphabet = lowercaseAlphabets.length > 0 ? [lowercaseAlphabets.sort().pop()] : [];

//     res.json({
//       is_success: true,
//       user_id: USER_ID,
//       email: EMAIL,
//       roll_number: ROLL_NUMBER,
//       numbers: numbers,
//       alphabets: alphabets,
//       highest_lowercase_alphabet: highestLowercaseAlphabet
//     });
//   } catch (error) {
//     res.status(500).json({ is_success: false, message: 'Internal server error' });
//   }
// });

// app.get('/bfhl', (req, res) => {
//   res.json({ operation_code: 1 });
// });

// app.listen(3001, () => {
//     console.log(`Server listening on port ${3001}`);
//   });
// const express = require('express');
// const cors = require('cors');
// const bodyParser = require('body-parser');

// const app = express();
// const PORT = process.env.PORT || 3000;

// app.use(cors());
// app.use(bodyParser.json());

// // Your user details
// const USER_ID = 'john_doe_17091999';
// const EMAIL = 'john@xyz.com';
// const ROLL_NUMBER = 'ABCD123';

// // Root route
// app.get('/', (req, res) => {
//   res.json({ message: 'Welcome to the BFHL API. Use /bfhl endpoint for POST and GET requests.' });
// });

// app.post('/bfhl', (req, res) => {
//   try {
//     const { data } = req.body;

//     if (!Array.isArray(data)) {
//       return res.status(400).json({ is_success: false, message: 'Invalid input: data must be an array' });
//     }

//     const numbers = data.filter(item => !isNaN(item));
//     const alphabets = data.filter(item => isNaN(item));
//     const lowercaseAlphabets = alphabets.filter(item => item.toLowerCase() === item);
//     const highestLowercaseAlphabet = lowercaseAlphabets.length > 0 ? [lowercaseAlphabets.sort().pop()] : [];

//     res.json({
//       is_success: true,
//       user_id: USER_ID,
//       email: EMAIL,
//       roll_number: ROLL_NUMBER,
//       numbers: numbers,
//       alphabets: alphabets,
//       highest_alphabet: highestLowercaseAlphabet
//     });
//   } catch (error) {
//     console.error('Error in POST /bfhl:', error);
//     res.status(500).json({ is_success: false, message: 'Internal server error' });
//   }
// });

// app.get('/bfhl', (req, res) => {
//   res.json({ operation_code: 1 });
// });

// // Handle 404 - Not Found
// app.use((req, res) => {
//   res.status(404).json({ message: 'Not Found. Use /bfhl endpoint for POST and GET requests.' });
// });

// app.listen(3001, () => {
//   console.log(`Server listening on port ${3001}`);
// });
// const express = require('express');
// const cors = require('cors');
// const bodyParser = require('body-parser');

// const app = express();
// const PORT = process.env.PORT || 3000;

// app.use(cors());
// app.use(bodyParser.json());

// // Your user details
// const USER_ID = 'john_doe_17091999';
// const EMAIL = 'john@xyz.com';
// const ROLL_NUMBER = 'ABCD123';

// // Root route
// app.get('/', (req, res) => {
//   res.json({ message: 'Welcome to the BFHL API. Use /bfhl endpoint for POST and GET requests.' });
// });

// app.post('/bfhl', (req, res) => {
//   console.log('Received POST request to /bfhl');
//   console.log('Request body:', req.body);

//   try {
//     const { data } = req.body;

//     if (!data || !Array.isArray(data)) {
//       console.log('Invalid input: data is not an array');
//       return res.status(400).json({ is_success: false, message: 'Invalid input: data must be an array' });
//     }

//     const numbers = data.filter(item => !isNaN(item));
//     const alphabets = data.filter(item => isNaN(item));
//     const lowercaseAlphabets = alphabets.filter(item => item.toLowerCase() === item);
//     const highestAlphabet = lowercaseAlphabets.length > 0 ? [lowercaseAlphabets.sort().pop()] : [];

//     const response = {
//       is_success: true,
//       user_id: USER_ID,
//       email: EMAIL,
//       roll_number: ROLL_NUMBER,
//       numbers: numbers,
//       alphabets: alphabets,
//       highest_alphabet: highestAlphabet
//     };

//     console.log('Sending response:', response);
//     res.json(response);
//   } catch (error) {
//     console.error('Error in POST /bfhl:', error);
//     res.status(500).json({ is_success: false, message: 'Internal server error', error: error.message });
//   }
// });

// app.get('/bfhl', (req, res) => {
//   console.log('Received GET request to /bfhl');
//   res.json({ operation_code: 1 });
// });

// // Handle 404 - Not Found
// app.use((req, res) => {
//   console.log('404 - Not Found:', req.method, req.url);
//   res.status(404).json({ message: 'Not Found. Use /bfhl endpoint for POST and GET requests.' });
// });

// app.listen(3001, () => {
//   console.log(`Server is running on port ${3001}`);
// });
// const express = require('express');
// const cors = require('cors');
// const bodyParser = require('body-parser');

// const app = express();
// const PORT = process.env.PORT || 3000;

// app.use(cors());
// app.use(bodyParser.json());

// // Your user details
// const USER_ID = 'john_doe_17091999';
// const EMAIL = 'john@xyz.com';
// const ROLL_NUMBER = 'ABCD123';

// // Root route
// app.get('/', (req, res) => {
//   res.json({ message: 'Welcome to the BFHL API. Use /bfhl endpoint for POST and GET requests.' });
// });

// app.post('/bfhl', (req, res) => {
//   console.log('Received POST request to /bfhl');
//   console.log('Request body:', req.body);

//   try {
//     const { data } = req.body;

//     if (!data || !Array.isArray(data)) {
//       console.log('Invalid input: data is not an array');
//       return res.status(400).json({ is_success: false, message: 'Invalid input: data must be an array' });
//     }

//     const numbers = data.filter(item => !isNaN(item));
//     const alphabets = data.filter(item => isNaN(item));
//     const highestAlphabet = alphabets.length > 0 ? [alphabets.sort((a, b) => b.localeCompare(a, undefined, {sensitivity: 'base'}))[0]] : [];

//     const response = {
//       is_success: true,
//       user_id: USER_ID,
//       email: EMAIL,
//       roll_number: ROLL_NUMBER,
//       numbers: numbers,
//       alphabets: alphabets,
//       highest_alphabet: highestAlphabet
//     };

//     console.log('Sending response:', response);
//     res.json(response);
//   } catch (error) {
//     console.error('Error in POST /bfhl:', error);
//     res.status(500).json({ is_success: false, message: 'Internal server error', error: error.message });
//   }
// });

// app.get('/bfhl', (req, res) => {
//   console.log('Received GET request to /bfhl');
//   res.json({ operation_code: 1 });
// });

// // Handle 404 - Not Found
// app.use((req, res) => {
//   console.log('404 - Not Found:', req.method, req.url);
//   res.status(404).json({ message: 'Not Found. Use /bfhl endpoint for POST and GET requests.' });
// });

// app.listen(3001, () => {
//   console.log(`Server is running on port ${3001}`);
// });
const express = require('express');
const app = express();
const cors = require('cors');
const bodyParser = require('body-parser');

app.use(cors({ origin: 'http://localhost:3000' })); 
app.use(bodyParser.json());
app.use(express.json());

app.post('/bfhl', (req, res) => {
    const data = req.body.data;
    const userId = "john_doe_17091999";  // Replace with actual logic
    const email = "john@xyz.com";  // Replace with actual email
    const rollNumber = "ABCD123";  // Replace with actual roll number

    // Filter numbers and alphabets
    const numbers = data.filter(item => !isNaN(item));
    const alphabets = data.filter(item => isNaN(item));

    // Find the highest lowercase alphabet
    const lowerCaseAlphabets = alphabets.filter(item => item === item.toLowerCase());
    const highestLowercase = lowerCaseAlphabets.length > 0 ? [Math.max(...lowerCaseAlphabets)] : [];

    // Construct response
    const response = {
        is_success: true,
        user_id: userId,
        email: email,
        roll_number: rollNumber,
        numbers: numbers,
        alphabets: alphabets,
        highest_lowercase_alphabet: highestLowercase
    };

    res.json(response);
});

app.get('/bfhl', (req, res) => {
    res.status(200).json({ operation_code: 1 });
});

const PORT = process.env.PORT || 3000;
app.listen(3001, () => {
    console.log(`Server is running on port ${3001}`);
});